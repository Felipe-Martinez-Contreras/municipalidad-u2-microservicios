# usuarios/admin.py
# Registro del modelo Usuario en el panel de administración
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html

from .models import Usuario


@admin.register(Usuario)
class UsuarioAdmin(BaseUserAdmin):
    """Administración personalizada de usuarios."""

    # Campos que se muestran en la lista
    list_display = [
        'email',
        'rut',
        'nombre_completo',
        'rol_coloreado',
        'departamento',
        'is_active',
        'date_joined',
    ]
    list_filter = [
        'rol',
        'departamento',
        'is_active',
        'is_staff',
        'date_joined',
    ]
    search_fields = [
        'email',
        'first_name',
        'last_name',
        'rut',
    ]
    ordering = ['email']

    # Campos en el formulario de edición
    fieldsets = (
        ('Credenciales', {
            'fields': ('email', 'password'),
        }),
        ('Información personal', {
            'fields': ('first_name', 'last_name', 'rut', 'telefono'),
        }),
        ('Rol y departamento', {
            'fields': ('rol', 'departamento'),
        }),
        ('Permisos', {
            'fields': (
                'is_active',
                'is_staff',
                'is_superuser',
                'groups',
                'user_permissions',
            ),
        }),
        ('Fechas importantes', {
            'fields': ('last_login', 'date_joined'),
            'classes': ('collapse',),
        }),
    )

    # Campos en el formulario de creación
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'email',
                'first_name',
                'last_name',
                'rut',
                'rol',
                'departamento',
                'password1',
                'password2',
            ),
        }),
    )

    readonly_fields = ['last_login', 'date_joined']

    def nombre_completo(self, obj):
        return obj.get_full_name() or 'Sin nombre'

    nombre_completo.short_description = 'Nombre completo'

    def rol_coloreado(self, obj):
        """Muestra el rol con color distintivo."""
        colores = {
            'ciudadano': '#3498db',
            'funcionario': '#2ecc71',
            'bodeguero': '#e67e22',
            'jefatura': '#9b59b6',
            'admin': '#e74c3c',
        }
        color = colores.get(obj.rol, '#95a5a6')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 10px; '
            'border-radius: 10px; font-size: 0.85rem;">{}</span>',
            color,
            obj.get_rol_display(),
        )

    rol_coloreado.short_description = 'Rol'
    rol_coloreado.admin_order_field = 'rol'
