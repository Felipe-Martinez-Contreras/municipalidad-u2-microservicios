from django.contrib.auth.models import AbstractUser
from django.db import models


class Usuario(AbstractUser):
    """
    Modelo de usuario personalizado que extiende AbstractUser.
    Permite autenticación por email y añade campos específicos del municipio.
    """

    class RolChoices(models.TextChoices):
        CIUDADANO = 'ciudadano', 'Ciudadano'
        FUNCIONARIO = 'funcionario', 'Funcionario Municipal'
        BODEGUERO = 'bodeguero', 'Encargado de Bodega'
        JEFATURA = 'jefatura', 'Jefatura'
        ADMIN = 'admin', 'Administrador'

    class DeptoChoices(models.TextChoices):
        DIDECO = 'dideco', 'Dideco'
        OMIL = 'omil', 'OMIL'
        TESORERIA = 'tesoreria', 'Tesorería'
        SALUD = 'salud', 'Salud'
        EDUCACION = 'educacion', 'Educación'
        BODEGA = 'bodega', 'Bodega'
        INFORMATICA = 'informatica', 'Informática'
        OTRO = 'otro', 'Otro'

    # Sobrescribir el campo email para hacerlo único y requerido para login
    email = models.EmailField(
        unique=True,
        verbose_name='Correo electrónico',
    )

    # Campos personalizados
    rol = models.CharField(
        max_length=20,
        choices=RolChoices.choices,
        default=RolChoices.CIUDADANO,
        verbose_name='Rol del usuario',
    )

    departamento = models.CharField(
        max_length=20,
        choices=DeptoChoices.choices,
        blank=True,
        default='',
        verbose_name='Departamento',
    )

    rut = models.CharField(
        max_length=12,
        unique=True,
        verbose_name='RUT',
        help_text='Formato: 12345678-9',
    )

    telefono = models.CharField(
        max_length=15,
        blank=True,
        verbose_name='Teléfono',
    )

    # Configuración de autenticación por email
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'rut']

    def __str__(self):
        return f'{self.get_full_name()} ({self.rut})'

    @property
    def es_ciudadano(self):
        return self.rol == self.RolChoices.CIUDADANO

    @property
    def es_funcionario(self):
        return self.rol == self.RolChoices.FUNCIONARIO

    @property
    def es_bodeguero(self):
        return self.rol == self.RolChoices.BODEGUERO

    @property
    def es_jefatura(self):
        return self.rol == self.RolChoices.JEFATURA

    @property
    def es_admin(self):
        return self.rol == self.RolChoices.ADMIN or self.is_superuser

    class Meta:
        verbose_name = 'Usuario'
        verbose_name_plural = 'Usuarios'
        ordering = ['-date_joined']
        db_table = 'usuarios_usuario'  # Mantenemos el nombre de tabla controlado



