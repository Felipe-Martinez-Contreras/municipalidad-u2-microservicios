# tramites/views.py
# Vistas para la plataforma de trámites municipales
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q

from .models import Tramite, DocumentoTramite, HistorialTramite
from .forms import (
    FormularioCrearTramite,
    FormularioDocumento,
    FormularioCambiarEstado,
    FormularioFiltrarTramites,
)


@login_required
def crear_tramite(request):
    """
    Vista para que un ciudadano cree un nuevo trámite.
    Solo usuarios con rol 'ciudadano' pueden crear trámites.
    """
    # Verificar que sea ciudadano
    if not request.user.es_ciudadano:
        messages.error(request, 'Solo los ciudadanos pueden crear trámites.')
        return redirect('dashboard')

    if request.method == 'POST':
        form = FormularioCrearTramite(request.POST)
        if form.is_valid():
            tramite = form.save(commit=False)
            tramite.ciudadano = request.user
            tramite.save()

            # Registrar en el historial
            HistorialTramite.objects.create(
                tramite=tramite,
                usuario=request.user,
                accion='creacion',
                estado_nuevo='ingresado',
                observacion='Trámite creado por el ciudadano.',
            )

            messages.success(
                request,
                f'¡Trámite creado exitosamente! Su código de seguimiento es: '
                f'<strong>{tramite.codigo_seguimiento}</strong>. '
                f'Guárdelo para consultar el estado.',
            )
            return redirect('tramites:detalle_tramite', codigo=tramite.codigo_seguimiento)
    else:
        form = FormularioCrearTramite()

    return render(request, 'tramites/crear.html', {
        'form': form,
        'titulo': 'Nuevo Trámite',
    })


@login_required
def mis_tramites(request):
    """
    Lista de trámites del ciudadano autenticado.
    """
    if not request.user.es_ciudadano:
        messages.error(request, 'Esta sección es solo para ciudadanos.')
        return redirect('dashboard')

    tramites = Tramite.objects.filter(ciudadano=request.user).order_by('-creado_en')

    return render(request, 'tramites/mis_tramites.html', {
        'tramites': tramites,
        'titulo': 'Mis Trámites',
    })


@login_required
def detalle_tramite(request, codigo):
    """
    Vista de detalle de un trámite (visible por ciudadano dueño y funcionarios).
    """
    tramite = get_object_or_404(Tramite, codigo_seguimiento=codigo)

    # Verificar permisos: dueño del trámite o funcionario/admin
    if not (
        tramite.ciudadano == request.user
        or request.user.es_funcionario
        or request.user.es_admin
        or request.user.rol in ['jefatura', 'bodeguero']
    ):
        messages.error(request, 'No tiene permisos para ver este trámite.')
        return redirect('dashboard')

    historial = tramite.historial.all()
    documentos = tramite.documentos.all()

    # Formulario para adjuntar documentos (solo el dueño)
    form_documento = None
    if tramite.ciudadano == request.user and tramite.estado in ['ingresado', 'observado']:
        if request.method == 'POST':
            form_documento = FormularioDocumento(request.POST, request.FILES)
            if form_documento.is_valid():
                documento = form_documento.save(commit=False)
                documento.tramite = tramite
                documento.nombre_original = request.FILES['archivo'].name
                documento.save()

                HistorialTramite.objects.create(
                    tramite=tramite,
                    usuario=request.user,
                    accion='documento_adjunto',
                    estado_nuevo=tramite.estado,
                    observacion=f'Documento adjuntado: {documento.nombre_original}',
                )

                messages.success(request, 'Documento adjuntado correctamente.')
                return redirect('tramites:detalle_tramite', codigo=codigo)
        else:
            form_documento = FormularioDocumento()

    # Formulario para cambiar estado (solo funcionarios)
    form_estado = None
    if (
        request.user.es_funcionario
        or request.user.es_admin
        or request.user.rol in ['jefatura']
    ):
        if request.method == 'POST' and 'cambiar_estado' in request.POST:
            form_estado = FormularioCambiarEstado(request.POST, instance=tramite)
            if form_estado.is_valid():
                estado_anterior = tramite.estado
                tramite_actualizado = form_estado.save(commit=False)
                tramite_actualizado.funcionario_asignado = request.user
                tramite_actualizado.save()

                HistorialTramite.objects.create(
                    tramite=tramite_actualizado,
                    usuario=request.user,
                    accion='cambio_estado',
                    estado_anterior=estado_anterior,
                    estado_nuevo=tramite_actualizado.estado,
                    observacion=form_estado.cleaned_data.get('observacion', ''),
                )

                messages.success(
                    request,
                    f'Estado actualizado: {tramite_actualizado.get_estado_display()}',
                )
                return redirect('tramites:detalle_tramite', codigo=codigo)
        else:
            form_estado = FormularioCambiarEstado(instance=tramite)

    return render(request, 'tramites/detalle.html', {
        'tramite': tramite,
        'historial': historial,
        'documentos': documentos,
        'form_documento': form_documento,
        'form_estado': form_estado,
        'titulo': f'Trámite {tramite.codigo_seguimiento}',
    })


@login_required
def bandeja_tramites(request):
    """
    Bandeja de trámites para funcionarios.
    Muestra trámites filtrables por estado, tipo y búsqueda.
    """
    # Verificar que sea funcionario, admin o jefatura
    if not (
        request.user.es_funcionario
        or request.user.es_admin
        or request.user.es_jefatura
    ):
        messages.error(request, 'No tiene permisos para acceder a esta sección.')
        return redirect('dashboard')

    tramites = Tramite.objects.all()

    # Aplicar filtros
    form_filtro = FormularioFiltrarTramites(request.GET or None)

    if form_filtro.is_valid():
        estado = form_filtro.cleaned_data.get('estado')
        tipo = form_filtro.cleaned_data.get('tipo')
        busqueda = form_filtro.cleaned_data.get('busqueda')

        if estado:
            tramites = tramites.filter(estado=estado)
        if tipo:
            tramites = tramites.filter(tipo=tipo)
        if busqueda:
            tramites = tramites.filter(
                Q(codigo_seguimiento__icontains=busqueda)
                | Q(descripcion__icontains=busqueda)
                | Q(ciudadano__rut__icontains=busqueda)
                | Q(ciudadano__email__icontains=busqueda)
            )

    tramites = tramites.order_by('-creado_en')

    # Estadísticas para el panel
    totales = {
        'total': Tramite.objects.count(),
        'ingresados': Tramite.objects.filter(estado='ingresado').count(),
        'en_revision': Tramite.objects.filter(estado='en_revision').count(),
        'observados': Tramite.objects.filter(estado='observado').count(),
        'aprobados': Tramite.objects.filter(estado='aprobado').count(),
        'rechazados': Tramite.objects.filter(estado='rechazado').count(),
        'finalizados': Tramite.objects.filter(estado='finalizado').count(),
    }

    return render(request, 'tramites/bandeja.html', {
        'tramites': tramites,
        'form_filtro': form_filtro,
        'totales': totales,
        'titulo': 'Bandeja de Trámites',
    })
