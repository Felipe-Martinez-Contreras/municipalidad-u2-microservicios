# tramites/admin.py
# Registro de modelos en el panel de administración de Django
from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from .models import TipoTramite, Tramite, DocumentoTramite, HistorialTramite


@admin.register(TipoTramite)
class TipoTramiteAdmin(admin.ModelAdmin):
    """Administración de tipos de trámite configurables."""

    list_display = [
        'nombre',
        'activo',
        'requiere_documentos',
        'departamento_responsable',
        'total_tramites',
        'creado_en',
    ]
    list_filter = ['activo', 'requiere_documentos', 'departamento_responsable']
    search_fields = ['nombre', 'descripcion']
    ordering = ['nombre']
    fieldsets = (
        ('Información general', {
            'fields': ('nombre', 'descripcion', 'activo'),
        }),
        ('Configuración', {
            'fields': ('requiere_documentos', 'departamento_responsable'),
        }),
    )

    def total_tramites(self, obj):
        """Muestra cuántos trámites se han creado de este tipo."""
        count = obj.tramites.count()
        if count > 0:
            url = reverse('admin:tramites_tramite_changelist') + f'?tipo__id__exact={obj.pk}'
            return format_html('<a href="{}">{} trámites</a>', url, count)
        return '0 trámites'

    total_tramites.short_description = 'Trámites'


class DocumentoTramiteInline(admin.TabularInline):
    """Muestra documentos dentro del detalle del trámite."""

    model = DocumentoTramite
    extra = 0
    readonly_fields = ['nombre_original', 'archivo', 'subido_en']
    fields = ['nombre_original', 'archivo', 'subido_en']


class HistorialTramiteInline(admin.TabularInline):
    """Muestra el historial dentro del detalle del trámite."""

    model = HistorialTramite
    extra = 0
    readonly_fields = ['fecha', 'usuario', 'accion', 'estado_anterior', 'estado_nuevo', 'observacion']
    fields = ['fecha', 'usuario', 'accion', 'estado_anterior', 'estado_nuevo']
    ordering = ['-fecha']
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Tramite)
class TramiteAdmin(admin.ModelAdmin):
    """Administración de trámites con vista completa."""

    list_display = [
        'codigo_seguimiento',
        'tipo',
        'ciudadano',
        'estado_coloreado',
        'funcionario_asignado',
        'creado_en',
    ]
    list_filter = [
        'estado',
        'tipo',
        'funcionario_asignado',
        'creado_en',
    ]
    search_fields = [
        'codigo_seguimiento',
        'ciudadano__email',
        'ciudadano__first_name',
        'ciudadano__last_name',
        'ciudadano__rut',
        'descripcion',
    ]
    readonly_fields = [
        'codigo_seguimiento',
        'creado_en',
        'actualizado_en',
    ]
    autocomplete_fields = ['ciudadano', 'funcionario_asignado', 'tipo']
    inlines = [DocumentoTramiteInline, HistorialTramiteInline]

    fieldsets = (
        ('Información del trámite', {
            'fields': ('codigo_seguimiento', 'tipo', 'estado'),
        }),
        ('Solicitante y asignación', {
            'fields': ('ciudadano', 'funcionario_asignado'),
        }),
        ('Detalle', {
            'fields': ('descripcion',),
        }),
        ('Fechas', {
            'fields': ('creado_en', 'actualizado_en'),
            'classes': ('collapse',),
        }),
    )

    def estado_coloreado(self, obj):
        """Muestra el estado con un color según su valor."""
        colores = {
            'ingresado': '#3498db',       # Azul
            'en_revision': '#f39c12',      # Naranja
            'observado': '#e74c3c',        # Rojo
            'aprobado': '#2ecc71',         # Verde
            'rechazado': '#c0392b',        # Rojo oscuro
            'finalizado': '#7f8c8d',       # Gris
        }
        color = colores.get(obj.estado, '#95a5a6')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 4px 10px; '
            'border-radius: 12px; font-size: 0.85rem; font-weight: 500;">{}</span>',
            color,
            obj.get_estado_display(),
        )

    estado_coloreado.short_description = 'Estado'
    estado_coloreado.admin_order_field = 'estado'

    def save_model(self, request, obj, form, change):
        """Registra en el historial cuando se modifica desde admin."""
        if change:
            original = Tramite.objects.get(pk=obj.pk)
            if original.estado != obj.estado:
                HistorialTramite.objects.create(
                    tramite=obj,
                    usuario=request.user,
                    accion='cambio_estado',
                    estado_anterior=original.estado,
                    estado_nuevo=obj.estado,
                    observacion='Cambio realizado desde panel de administración.',
                )
            if original.funcionario_asignado != obj.funcionario_asignado:
                HistorialTramite.objects.create(
                    tramite=obj,
                    usuario=request.user,
                    accion='asignacion',
                    estado_anterior='',
                    estado_nuevo=obj.estado,
                    observacion=f'Asignado a {obj.funcionario_asignado.get_full_name() if obj.funcionario_asignado else "Sin asignar"}.',
                )
        super().save_model(request, obj, form, change)


@admin.register(DocumentoTramite)
class DocumentoTramiteAdmin(admin.ModelAdmin):
    """Administración de documentos adjuntos."""

    list_display = ['nombre_original', 'tramite_link', 'tamano_archivo', 'subido_en']
    list_filter = ['subido_en']
    search_fields = ['nombre_original', 'tramite__codigo_seguimiento']
    readonly_fields = ['nombre_original', 'archivo', 'subido_en']

    def tramite_link(self, obj):
        url = reverse('admin:tramites_tramite_change', args=[obj.tramite.pk])
        return format_html('<a href="{}">{}</a>', url, obj.tramite.codigo_seguimiento)

    tramite_link.short_description = 'Trámite'

    def tamano_archivo(self, obj):
        """Muestra el tamaño del archivo en KB o MB."""
        try:
            size = obj.archivo.size
            if size < 1024 * 1024:
                return f'{size / 1024:.1f} KB'
            return f'{size / (1024 * 1024):.1f} MB'
        except Exception:
            return 'N/A'

    tamano_archivo.short_description = 'Tamaño'


@admin.register(HistorialTramite)
class HistorialTramiteAdmin(admin.ModelAdmin):
    """Administración del historial (solo lectura)."""

    list_display = ['tramite', 'fecha', 'accion', 'usuario', 'estado_anterior', 'estado_nuevo']
    list_filter = ['accion', 'fecha']
    search_fields = ['tramite__codigo_seguimiento', 'usuario__email', 'observacion']
    readonly_fields = ['tramite', 'usuario', 'accion', 'estado_anterior', 'estado_nuevo', 'observacion', 'fecha']
    ordering = ['-fecha']

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
