# tramites/urls.py
# Rutas de la plataforma de trámites municipales
from django.urls import path
from . import views

app_name = 'tramites'

urlpatterns = [
    # Rutas fijas PRIMERO (antes de la ruta con variable)
    path('nuevo/', views.crear_tramite, name='crear_tramite'),
    path('mis-tramites/', views.mis_tramites, name='mis_tramites'),
    path('bandeja/', views.bandeja_tramites, name='bandeja_tramites'),

    # Ruta con variable AL FINAL (captura el código de seguimiento)
    path('<str:codigo>/', views.detalle_tramite, name='detalle_tramite'),
]
