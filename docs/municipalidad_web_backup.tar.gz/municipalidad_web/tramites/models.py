# tramites/models.py
# Modelos para la plataforma de trámites municipales en línea
from django.db import models
from usuarios.models import Usuario


class TipoTramite(models.Model):
    """
    Tipos de trámite configurables por el administrador.
    Ej: Certificado de residencia, Solicitud de materiales, etc.
    """

    nombre = models.CharField(
        max_length=100,
        unique=True,
        verbose_name='Nombre del trámite',
    )

    descripcion = models.TextField(
        blank=True,
        verbose_name='Descripción',
        help_text='Descripción pública que verá el ciudadano al iniciar el trámite.',
    )

    activo = models.BooleanField(
        default=True,
        verbose_name='Activo',
        help_text='Desactivar para ocultar este tipo de trámite sin eliminarlo.',
    )

    requiere_documentos = models.BooleanField(
        default=True,
        verbose_name='Requiere documentos adjuntos',
        help_text='Si el ciudadano debe adjuntar archivos para completar la solicitud.',
    )

    departamento_responsable = models.CharField(
        max_length=20,
        choices=Usuario.DeptoChoices.choices,
        blank=True,
        default='',
        verbose_name='Departamento responsable',
        help_text='Departamento encargado de procesar este tipo de trámite.',
    )

    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Tipo de trámite'
        verbose_name_plural = 'Tipos de trámite'
        ordering = ['nombre']

    def __str__(self):
        return self.nombre


class Tramite(models.Model):
    """
    Solicitud de trámite realizada por un ciudadano.
    """

    class EstadoChoices(models.TextChoices):
        INGRESADO = 'ingresado', 'Ingresado'
        EN_REVISION = 'en_revision', 'En revisión'
        OBSERVADO = 'observado', 'Observado'
        APROBADO = 'aprobado', 'Aprobado'
        RECHAZADO = 'rechazado', 'Rechazado'
        FINALIZADO = 'finalizado', 'Finalizado'

    codigo_seguimiento = models.CharField(
        max_length=20,
        unique=True,
        verbose_name='Código de seguimiento',
        help_text='Código único tipo TRM-2026-000123',
    )

    tipo = models.ForeignKey(
        TipoTramite,
        on_delete=models.PROTECT,
        related_name='tramites',
        verbose_name='Tipo de trámite',
    )

    ciudadano = models.ForeignKey(
        Usuario,
        on_delete=models.CASCADE,
        related_name='tramites',
        limit_choices_to={'rol': 'ciudadano'},
        verbose_name='Ciudadano solicitante',
    )

    estado = models.CharField(
        max_length=20,
        choices=EstadoChoices.choices,
        default=EstadoChoices.INGRESADO,
        verbose_name='Estado actual',
    )

    descripcion = models.TextField(
        verbose_name='Descripción de la solicitud',
        help_text='Detalle de lo que el ciudadano necesita.',
    )

    funcionario_asignado = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='tramites_asignados',
        limit_choices_to={'rol__in': ['funcionario', 'admin']},
        verbose_name='Funcionario asignado',
    )

    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Trámite'
        verbose_name_plural = 'Trámites'
        ordering = ['-creado_en']
        permissions = [
            ('puede_asignar_tramite', 'Puede asignar trámites a funcionarios'),
            ('puede_cambiar_estado', 'Puede cambiar el estado de los trámites'),
        ]

    def __str__(self):
        return f'{self.codigo_seguimiento} - {self.tipo.nombre} ({self.get_estado_display()})'

    def save(self, *args, **kwargs):
        """Genera automáticamente el código de seguimiento si es nuevo."""
        if not self.codigo_seguimiento:
            ultimo = Tramite.objects.order_by('-id').first()
            numero = (ultimo.id + 1) if ultimo else 1
            from datetime import date
            year = date.today().year
            self.codigo_seguimiento = f'TRM-{year}-{numero:06d}'
        super().save(*args, **kwargs)


class DocumentoTramite(models.Model):
    """
    Documentos adjuntos a un trámite (PDF, imágenes).
    """

    tramite = models.ForeignKey(
        Tramite,
        on_delete=models.CASCADE,
        related_name='documentos',
        verbose_name='Trámite',
    )

    archivo = models.FileField(
        upload_to='tramites/documentos/%Y/%m/',
        verbose_name='Archivo adjunto',
        help_text='Formatos permitidos: PDF, JPG, PNG (máx. 5 MB)',
    )

    nombre_original = models.CharField(
        max_length=255,
        verbose_name='Nombre original del archivo',
    )

    subido_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Documento adjunto'
        verbose_name_plural = 'Documentos adjuntos'
        ordering = ['-subido_en']

    def __str__(self):
        return f'{self.nombre_original} ({self.tramite.codigo_seguimiento})'


class HistorialTramite(models.Model):
    """
    Registro de cambios de estado y acciones sobre un trámite.
    Proporciona trazabilidad completa (auditoría).
    """

    class AccionChoices(models.TextChoices):
        CREACION = 'creacion', 'Creación del trámite'
        CAMBIO_ESTADO = 'cambio_estado', 'Cambio de estado'
        ASIGNACION = 'asignacion', 'Asignación a funcionario'
        OBSERVACION = 'observacion', 'Observación agregada'
        DOCUMENTO_ADJUNTO = 'documento_adjunto', 'Documento adjuntado'

    tramite = models.ForeignKey(
        Tramite,
        on_delete=models.CASCADE,
        related_name='historial',
        verbose_name='Trámite',
    )

    usuario = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        related_name='acciones_historial',
        verbose_name='Usuario que realizó la acción',
    )

    accion = models.CharField(
        max_length=30,
        choices=AccionChoices.choices,
        verbose_name='Acción realizada',
    )

    estado_anterior = models.CharField(
        max_length=20,
        blank=True,
        verbose_name='Estado anterior',
    )

    estado_nuevo = models.CharField(
        max_length=20,
        blank=True,
        verbose_name='Estado nuevo',
    )

    observacion = models.TextField(
        blank=True,
        verbose_name='Observación',
    )

    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Historial de trámite'
        verbose_name_plural = 'Historial de trámites'
        ordering = ['-fecha']

    def __str__(self):
        return f'{self.tramite.codigo_seguimiento} - {self.get_accion_display()} ({self.fecha:%d/%m/%Y %H:%M})'
