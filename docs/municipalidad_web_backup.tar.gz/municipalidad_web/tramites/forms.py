# tramites/forms.py
# Formularios para la plataforma de trámites municipales
from django import forms
from django.core.validators import FileExtensionValidator

from .models import Tramite, DocumentoTramite, TipoTramite


class FormularioCrearTramite(forms.ModelForm):
    """
    Formulario para que el ciudadano cree una nueva solicitud de trámite.
    """

    class Meta:
        model = Tramite
        fields = ['tipo', 'descripcion']
        labels = {
            'tipo': 'Tipo de trámite',
            'descripcion': 'Describa su solicitud',
        }
        widgets = {
            'tipo': forms.Select(attrs={
                'class': 'form-select',
            }),
            'descripcion': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Describa detalladamente lo que necesita solicitar...',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Solo mostrar tipos de trámite activos
        self.fields['tipo'].queryset = TipoTramite.objects.filter(activo=True)
        if not self.fields['tipo'].queryset.exists():
            self.fields['tipo'].empty_label = 'No hay trámites disponibles'


class FormularioDocumento(forms.ModelForm):
    """
    Formulario para adjuntar un documento a un trámite existente.
    """

    archivo = forms.FileField(
        label='Seleccionar archivo',
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.pdf,.jpg,.jpeg,.png',
        }),
        validators=[
            FileExtensionValidator(
                allowed_extensions=['pdf', 'jpg', 'jpeg', 'png'],
                message='Solo se permiten archivos PDF, JPG y PNG.',
            ),
        ],
        help_text='Formatos permitidos: PDF, JPG, PNG. Máximo 5 MB.',
    )

    class Meta:
        model = DocumentoTramite
        fields = ['archivo']

    def clean_archivo(self):
        """Valida que el archivo no supere los 5 MB."""
        archivo = self.cleaned_data.get('archivo')
        if archivo:
            max_size = 5 * 1024 * 1024  # 5 MB
            if archivo.size > max_size:
                raise forms.ValidationError(
                    f'El archivo "{archivo.name}" supera el tamaño máximo permitido de 5 MB. '
                    f'Tamaño actual: {archivo.size / (1024 * 1024):.1f} MB.'
                )
        return archivo


class FormularioCambiarEstado(forms.ModelForm):
    """
    Formulario para que el funcionario cambie el estado del trámite.
    """

    observacion = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Agregue una observación sobre el cambio de estado...',
        }),
        label='Observación (opcional)',
    )

    class Meta:
        model = Tramite
        fields = ['estado']
        labels = {
            'estado': 'Nuevo estado',
        }
        widgets = {
            'estado': forms.Select(attrs={
                'class': 'form-select',
            }),
        }


class FormularioFiltrarTramites(forms.Form):
    """
    Formulario para filtrar trámites en la bandeja del funcionario.
    """

    estado = forms.ChoiceField(
        required=False,
        choices=[('', 'Todos los estados')] + list(Tramite.EstadoChoices.choices),
        widget=forms.Select(attrs={'class': 'form-select'}),
    )

    tipo = forms.ModelChoiceField(
        required=False,
        queryset=TipoTramite.objects.filter(activo=True),
        empty_label='Todos los tipos',
        widget=forms.Select(attrs={'class': 'form-select'}),
    )

    busqueda = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Buscar por código o descripción...',
        }),
    )
