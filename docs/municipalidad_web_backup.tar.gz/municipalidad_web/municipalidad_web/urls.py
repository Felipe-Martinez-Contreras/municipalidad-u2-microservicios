# municipalidad_web/urls.py
# URLs principales del proyecto
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('portal.urls')),
    path('tramites/', include('tramites.urls')),
    path('bodega/', include('bodega.urls')),
    path('administracion/', include('administracion.urls')),
    path('', include('django_prometheus.urls')),
#    path('error-test/', views.test_error_view, name='error-test'),
]

# Servir archivos de MEDIA en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
