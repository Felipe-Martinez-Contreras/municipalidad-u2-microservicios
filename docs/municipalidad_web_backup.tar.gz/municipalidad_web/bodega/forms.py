# bodega/forms.py
# Formularios para la gestión de bodega municipal
from django import forms
from django.core.validators import MinValueValidator

from .models import SolicitudBodega, DetalleSolicitud, Producto, MovimientoStock, CategoriaProducto


class FormularioSolicitudBodega(forms.ModelForm):
    """
    Formulario para crear una solicitud de materiales a bodega.
    """

    class Meta:
        model = SolicitudBodega
        fields = ['departamento_solicitante', 'justificacion']
        labels = {
            'departamento_solicitante': 'Departamento solicitante',
            'justificacion': 'Justificación de la solicitud',
        }
        widgets = {
            'departamento_solicitante': forms.Select(attrs={
                'class': 'form-select',
            }),
            'justificacion': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Explique por qué necesita estos materiales...',
            }),
        }


class FormularioDetalleSolicitud(forms.ModelForm):
    """
    Formulario para agregar un producto a la solicitud.
    """

    class Meta:
        model = DetalleSolicitud
        fields = ['producto', 'cantidad_solicitada']
        labels = {
            'producto': 'Producto',
            'cantidad_solicitada': 'Cantidad',
        }
        widgets = {
            'producto': forms.Select(attrs={
                'class': 'form-select',
            }),
            'cantidad_solicitada': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'placeholder': 'Cantidad requerida',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Solo mostrar productos activos con stock > 0
        self.fields['producto'].queryset = Producto.objects.filter(
            activo=True,
        )


class FormularioAprobarSolicitud(forms.ModelForm):
    """
    Formulario para que jefatura apruebe o rechace una solicitud.
    """

    class Meta:
        model = SolicitudBodega
        fields = ['estado', 'observacion_respuesta']
        labels = {
            'estado': 'Decisión',
            'observacion_respuesta': 'Observación (opcional)',
        }
        widgets = {
            'estado': forms.Select(attrs={
                'class': 'form-select',
            }),
            'observacion_respuesta': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Motivo de aprobación o rechazo...',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Solo mostrar opciones de aprobación/rechazo
        self.fields['estado'].choices = [
            ('aprobada', '✅ Aprobar solicitud'),
            ('rechazada', '❌ Rechazar solicitud'),
        ]


class FormularioEntregarSolicitud(forms.ModelForm):
    """
    Formulario para que bodeguero registre la entrega de productos.
    """

    class Meta:
        model = SolicitudBodega
        fields = ['estado']
        labels = {
            'estado': 'Marcar como entregada',
        }
        widgets = {
            'estado': forms.HiddenInput(),
        }


class FormularioFiltrarInventario(forms.Form):
    """Filtros para la vista de inventario."""

    categoria = forms.ModelChoiceField(
        required=False,
        queryset=CategoriaProducto.objects.filter(activo=True),
        empty_label='Todas las categorías',
        widget=forms.Select(attrs={'class': 'form-select'}),
    )

    busqueda = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Buscar por código o nombre...',
        }),
    )

    solo_stock_bajo = forms.BooleanField(
        required=False,
        label='Solo productos con stock bajo',
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}),
    )
