# bodega/admin.py
# Registro de modelos de bodega en el panel de administración
from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from .models import (
    CategoriaProducto,
    Producto,
    MovimientoStock,
    SolicitudBodega,
    DetalleSolicitud,
)


@admin.register(CategoriaProducto)
class CategoriaProductoAdmin(admin.ModelAdmin):
    """Administración de categorías de productos."""

    list_display = ['nombre', 'activo', 'total_productos', 'creado_en']
    list_filter = ['activo']
    search_fields = ['nombre']
    ordering = ['nombre']

    def total_productos(self, obj):
        count = obj.productos.count()
        if count > 0:
            url = reverse('admin:bodega_producto_changelist') + f'?categoria__id__exact={obj.pk}'
            return format_html('<a href="{}">{} productos</a>', url, count)
        return '0 productos'

    total_productos.short_description = 'Productos'


class MovimientoStockInline(admin.TabularInline):
    """Historial de movimientos dentro del detalle del producto."""

    model = MovimientoStock
    extra = 0
    readonly_fields = ['tipo', 'cantidad', 'stock_anterior', 'stock_resultante', 'usuario', 'observacion', 'fecha']
    fields = ['fecha', 'tipo', 'cantidad', 'stock_anterior', 'stock_resultante', 'usuario', 'observacion']
    ordering = ['-fecha']
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    """Administración de productos con alerta de stock bajo."""

    list_display = [
        'codigo',
        'nombre',
        'categoria',
        'stock_coloreado',
        'stock_minimo',
        'unidad_medida',
        'precio_unitario',
        'valor_total',
        'activo',
    ]
    list_filter = ['activo', 'categoria', 'unidad_medida']
    search_fields = ['codigo', 'nombre', 'descripcion']
    ordering = ['-stock_actual', 'nombre']
    inlines = [MovimientoStockInline]

    fieldsets = (
        ('Información general', {
            'fields': ('codigo', 'nombre', 'descripcion', 'categoria', 'activo'),
        }),
        ('Inventario', {
            'fields': ('unidad_medida', 'stock_actual', 'stock_minimo', 'precio_unitario'),
        }),
        ('Fechas', {
            'fields': ('creado_en', 'actualizado_en'),
            'classes': ('collapse',),
        }),
    )
    readonly_fields = ['creado_en', 'actualizado_en']

    def stock_coloreado(self, obj):
        """Muestra el stock con color según esté bajo o normal."""
        if obj.stock_actual == 0:
            color = '#e74c3c'  # Rojo: sin stock
            icono = '🔴'
        elif obj.stock_actual <= obj.stock_minimo:
            color = '#f39c12'  # Naranja: stock bajo
            icono = '🟡'
        else:
            color = '#2ecc71'  # Verde: stock normal
            icono = '🟢'
        return format_html(
            '<span style="color: {}; font-weight: bold;">{} {}</span>',
            color, icono, obj.stock_actual,
        )

    stock_coloreado.short_description = 'Stock'
    stock_coloreado.admin_order_field = 'stock_actual'

    def valor_total(self, obj):
        """Valor total del inventario de este producto."""
        return f'${obj.valor_total_stock:,.0f}'

    valor_total.short_description = 'Valor total'
    valor_total.admin_order_field = 'stock_actual'

    def save_model(self, request, obj, form, change):
        """Registra movimiento cuando se modifica el stock desde admin."""
        if change:
            original = Producto.objects.get(pk=obj.pk)
            if original.stock_actual != obj.stock_actual:
                diferencia = obj.stock_actual - original.stock_actual
                MovimientoStock.objects.create(
                    producto=obj,
                    tipo='entrada' if diferencia > 0 else 'salida',
                    cantidad=abs(diferencia),
                    stock_anterior=original.stock_actual,
                    stock_resultante=obj.stock_actual,
                    usuario=request.user,
                    observacion='Ajuste manual desde panel de administración.',
                )
        super().save_model(request, obj, form, change)


@admin.register(MovimientoStock)
class MovimientoStockAdmin(admin.ModelAdmin):
    """Historial completo de movimientos (solo lectura)."""

    list_display = ['fecha', 'producto', 'tipo_movimiento', 'cantidad', 'stock_anterior', 'stock_resultante', 'usuario']
    list_filter = ['tipo', 'fecha']
    search_fields = ['producto__nombre', 'producto__codigo', 'observacion']
    readonly_fields = ['producto', 'tipo', 'cantidad', 'stock_anterior', 'stock_resultante', 'usuario', 'observacion', 'fecha']
    ordering = ['-fecha']

    def tipo_movimiento(self, obj):
        if obj.tipo == 'entrada':
            return format_html('<span style="color: green;">⬆ {}</span>', obj.get_tipo_display())
        return format_html('<span style="color: red;">⬇ {}</span>', obj.get_tipo_display())

    tipo_movimiento.short_description = 'Tipo'

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


class DetalleSolicitudInline(admin.TabularInline):
    """Productos solicitados dentro de la solicitud."""

    model = DetalleSolicitud
    extra = 1
    autocomplete_fields = ['producto']


@admin.register(SolicitudBodega)
class SolicitudBodegaAdmin(admin.ModelAdmin):
    """Administración de solicitudes de bodega."""

    list_display = [
        'codigo',
        'departamento_solicitante',
        'solicitante',
        'estado_coloreado',
        'aprobado_por',
        'creado_en',
    ]
    list_filter = ['estado', 'departamento_solicitante', 'creado_en']
    search_fields = ['codigo', 'solicitante__email', 'justificacion']
    readonly_fields = ['codigo', 'creado_en', 'actualizado_en']
    autocomplete_fields = ['solicitante', 'aprobado_por']
    inlines = [DetalleSolicitudInline]

    fieldsets = (
        ('Información de la solicitud', {
            'fields': ('codigo', 'departamento_solicitante', 'solicitante', 'estado'),
        }),
        ('Detalle', {
            'fields': ('justificacion',),
        }),
        ('Aprobación', {
            'fields': ('aprobado_por', 'observacion_respuesta'),
        }),
        ('Fechas', {
            'fields': ('creado_en', 'actualizado_en'),
            'classes': ('collapse',),
        }),
    )

    def estado_coloreado(self, obj):
        colores = {
            'ingresada': '#3498db',
            'pendiente': '#f39c12',
            'aprobada': '#2ecc71',
            'rechazada': '#e74c3c',
            'entregada': '#9b59b6',
        }
        color = colores.get(obj.estado, '#95a5a6')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 4px 10px; '
            'border-radius: 12px; font-size: 0.85rem;">{}</span>',
            color, obj.get_estado_display(),
        )

    estado_coloreado.short_description = 'Estado'
    estado_coloreado.admin_order_field = 'estado'


@admin.register(DetalleSolicitud)
class DetalleSolicitudAdmin(admin.ModelAdmin):
    """Detalles de solicitudes."""

    list_display = ['solicitud', 'producto', 'cantidad_solicitada', 'cantidad_entregada']
    search_fields = ['solicitud__codigo', 'producto__nombre']
    autocomplete_fields = ['solicitud', 'producto']
