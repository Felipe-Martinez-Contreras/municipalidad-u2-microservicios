# bodega/urls.py
# Rutas del sistema de gestión de bodega municipal
from django.urls import path
from . import views

app_name = 'bodega'

urlpatterns = [
    # Inventario
    path('inventario/', views.inventario, name='inventario'),
    path('producto/<int:producto_id>/', views.detalle_producto, name='detalle_producto'),

    # Solicitudes
    path('solicitudes/nueva/', views.crear_solicitud, name='crear_solicitud'),
    path('solicitudes/mis/', views.mis_solicitudes, name='mis_solicitudes'),
    path('solicitudes/pendientes/', views.solicitudes_pendientes, name='solicitudes_pendientes'),
    path('solicitudes/<int:solicitud_id>/', views.detalle_solicitud, name='detalle_solicitud'),
    path('solicitudes/<int:solicitud_id>/agregar/', views.agregar_productos, name='agregar_productos'),
]
