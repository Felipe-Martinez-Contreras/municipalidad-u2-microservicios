# bodega/models.py
# Modelos para la gestión de bodega municipal
from django.db import models
from django.core.validators import MinValueValidator
from usuarios.models import Usuario


class CategoriaProducto(models.Model):
    """
    Categorías para organizar productos en bodega.
    Ej: Materiales de oficina, Herramientas, Insumos de limpieza, etc.
    """

    nombre = models.CharField(
        max_length=100,
        unique=True,
        verbose_name='Nombre de la categoría',
    )

    descripcion = models.TextField(
        blank=True,
        verbose_name='Descripción',
    )

    activo = models.BooleanField(
        default=True,
        verbose_name='Activo',
    )

    creado_en = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Categoría de producto'
        verbose_name_plural = 'Categorías de productos'
        ordering = ['nombre']

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    """
    Producto en el inventario de bodega.
    """

    class UnidadChoices(models.TextChoices):
        UNIDAD = 'unidad', 'Unidad'
        CAJA = 'caja', 'Caja'
        KILO = 'kg', 'Kilogramo'
        LITRO = 'lt', 'Litro'
        METRO = 'mt', 'Metro'
        PACK = 'pack', 'Pack'
        RESMA = 'resma', 'Resma'
        OTRO = 'otro', 'Otro'

    codigo = models.CharField(
        max_length=20,
        unique=True,
        verbose_name='Código de producto',
        help_text='Código interno tipo PROD-001',
    )

    nombre = models.CharField(
        max_length=200,
        verbose_name='Nombre del producto',
    )

    descripcion = models.TextField(
        blank=True,
        verbose_name='Descripción',
    )

    categoria = models.ForeignKey(
        CategoriaProducto,
        on_delete=models.PROTECT,
        related_name='productos',
        verbose_name='Categoría',
    )

    unidad_medida = models.CharField(
        max_length=10,
        choices=UnidadChoices.choices,
        default=UnidadChoices.UNIDAD,
        verbose_name='Unidad de medida',
    )

    stock_actual = models.PositiveIntegerField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name='Stock actual',
    )

    stock_minimo = models.PositiveIntegerField(
        default=10,
        validators=[MinValueValidator(0)],
        verbose_name='Stock mínimo',
        help_text='Alerta cuando el stock baja de esta cantidad.',
    )

    precio_unitario = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        verbose_name='Precio unitario de referencia',
    )

    activo = models.BooleanField(
        default=True,
        verbose_name='Activo',
    )

    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Producto'
        verbose_name_plural = 'Productos'
        ordering = ['nombre']

    def __str__(self):
        return f'{self.codigo} - {self.nombre}'

    @property
    def stock_bajo(self):
        """Retorna True si el stock está bajo el mínimo."""
        return self.stock_actual <= self.stock_minimo

    @property
    def valor_total_stock(self):
        """Valor total del inventario de este producto."""
        return self.stock_actual * self.precio_unitario


class MovimientoStock(models.Model):
    """
    Registro de cada entrada o salida de stock (auditoría completa).
    """

    class TipoChoices(models.TextChoices):
        ENTRADA = 'entrada', 'Entrada'
        SALIDA = 'salida', 'Salida'

    producto = models.ForeignKey(
        Producto,
        on_delete=models.CASCADE,
        related_name='movimientos',
        verbose_name='Producto',
    )

    tipo = models.CharField(
        max_length=10,
        choices=TipoChoices.choices,
        verbose_name='Tipo de movimiento',
    )

    cantidad = models.PositiveIntegerField(
        validators=[MinValueValidator(1)],
        verbose_name='Cantidad',
    )

    stock_anterior = models.PositiveIntegerField(
        verbose_name='Stock anterior al movimiento',
    )

    stock_resultante = models.PositiveIntegerField(
        verbose_name='Stock después del movimiento',
    )

    usuario = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        related_name='movimientos_stock',
        verbose_name='Usuario que registró',
    )

    observacion = models.TextField(
        blank=True,
        verbose_name='Observación',
    )

    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Movimiento de stock'
        verbose_name_plural = 'Movimientos de stock'
        ordering = ['-fecha']

    def __str__(self):
        return f'{self.get_tipo_display()} - {self.producto.nombre} ({self.cantidad})'


class SolicitudBodega(models.Model):
    """
    Solicitud de materiales desde un departamento a bodega.
    Flujo: Ingresada → Pendiente → Aprobada/Rechazada → Entregada
    """

    class EstadoChoices(models.TextChoices):
        INGRESADA = 'ingresada', 'Ingresada'
        PENDIENTE = 'pendiente', 'Pendiente de aprobación'
        APROBADA = 'aprobada', 'Aprobada'
        RECHAZADA = 'rechazada', 'Rechazada'
        ENTREGADA = 'entregada', 'Entregada'

    codigo = models.CharField(
        max_length=20,
        unique=True,
        verbose_name='Código de solicitud',
        help_text='Código tipo SOL-2026-000123',
    )

    departamento_solicitante = models.CharField(
        max_length=20,
        choices=Usuario.DeptoChoices.choices,
        verbose_name='Departamento solicitante',
    )

    solicitante = models.ForeignKey(
        Usuario,
        on_delete=models.CASCADE,
        related_name='solicitudes_bodega',
        limit_choices_to={'rol__in': ['funcionario', 'bodeguero', 'jefatura', 'admin']},
        verbose_name='Solicitante',
    )

    estado = models.CharField(
        max_length=20,
        choices=EstadoChoices.choices,
        default=EstadoChoices.INGRESADA,
        verbose_name='Estado',
    )

    justificacion = models.TextField(
        verbose_name='Justificación',
        help_text='Explique por qué necesita estos materiales.',
    )

    aprobado_por = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='aprobaciones_bodega',
        limit_choices_to={'rol__in': ['jefatura', 'admin']},
        verbose_name='Aprobado por',
    )

    observacion_respuesta = models.TextField(
        blank=True,
        verbose_name='Observación de respuesta',
        help_text='Motivo de aprobación o rechazo.',
    )

    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Solicitud de bodega'
        verbose_name_plural = 'Solicitudes de bodega'
        ordering = ['-creado_en']
        permissions = [
            ('puede_aprobar_solicitud', 'Puede aprobar o rechazar solicitudes de bodega'),
            ('puede_entregar_solicitud', 'Puede marcar solicitudes como entregadas'),
        ]

    def __str__(self):
        return f'{self.codigo} - {self.get_departamento_solicitante_display()} ({self.get_estado_display()})'

    def save(self, *args, **kwargs):
        """Genera código automático si es nuevo."""
        if not self.codigo:
            ultimo = SolicitudBodega.objects.order_by('-id').first()
            numero = (ultimo.id + 1) if ultimo else 1
            from datetime import date
            year = date.today().year
            self.codigo = f'SOL-{year}-{numero:06d}'
        super().save(*args, **kwargs)


class DetalleSolicitud(models.Model):
    """
    Cada producto solicitado dentro de una solicitud de bodega.
    """

    solicitud = models.ForeignKey(
        SolicitudBodega,
        on_delete=models.CASCADE,
        related_name='detalles',
        verbose_name='Solicitud',
    )

    producto = models.ForeignKey(
        Producto,
        on_delete=models.PROTECT,
        related_name='detalles_solicitud',
        verbose_name='Producto',
    )

    cantidad_solicitada = models.PositiveIntegerField(
        validators=[MinValueValidator(1)],
        verbose_name='Cantidad solicitada',
    )

    cantidad_entregada = models.PositiveIntegerField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name='Cantidad entregada',
    )

    class Meta:
        verbose_name = 'Detalle de solicitud'
        verbose_name_plural = 'Detalles de solicitudes'

    def __str__(self):
        return f'{self.producto.nombre} x{self.cantidad_solicitada}'
