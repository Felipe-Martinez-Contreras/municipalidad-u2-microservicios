# bodega/views.py
# Vistas para el sistema de gestión de bodega municipal
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.db.models import Q, F

from .models import (
    Producto,
    CategoriaProducto,
    MovimientoStock,
    SolicitudBodega,
    DetalleSolicitud,
)
from .forms import (
    FormularioSolicitudBodega,
    FormularioDetalleSolicitud,
    FormularioAprobarSolicitud,
    FormularioEntregarSolicitud,
    FormularioFiltrarInventario,
)


@login_required
def inventario(request):
    """
    Vista del inventario de bodega.
    Accesible por: bodeguero, admin, jefatura.
    """
    if not (request.user.es_bodeguero or request.user.es_admin or request.user.es_jefatura):
        messages.error(request, 'No tiene permisos para acceder al inventario.')
        return redirect('dashboard')

    productos = Producto.objects.filter(activo=True).select_related('categoria')

    form_filtro = FormularioFiltrarInventario(request.GET or None)
    if form_filtro.is_valid():
        categoria = form_filtro.cleaned_data.get('categoria')
        busqueda = form_filtro.cleaned_data.get('busqueda')
        solo_stock_bajo = form_filtro.cleaned_data.get('solo_stock_bajo')

        if categoria:
            productos = productos.filter(categoria=categoria)
        if busqueda:
            productos = productos.filter(
                Q(codigo__icontains=busqueda) | Q(nombre__icontains=busqueda)
            )
        if solo_stock_bajo:
            productos = productos.filter(stock_actual__lte=F('stock_minimo'))

    # Estadísticas
    total_productos = productos.count()
    productos_stock_bajo = productos.filter(stock_actual__lte=F('stock_minimo')).count()
    productos_sin_stock = productos.filter(stock_actual=0).count()
    valor_total_inventario = sum(p.valor_total_stock for p in productos)

    return render(request, 'bodega/inventario.html', {
        'productos': productos,
        'form_filtro': form_filtro,
        'total_productos': total_productos,
        'productos_stock_bajo': productos_stock_bajo,
        'productos_sin_stock': productos_sin_stock,
        'valor_total_inventario': valor_total_inventario,
        'titulo': 'Inventario de Bodega',
    })


@login_required
def detalle_producto(request, producto_id):
    """
    Detalle de un producto con historial de movimientos.
    """
    if not (request.user.es_bodeguero or request.user.es_admin or request.user.es_jefatura):
        messages.error(request, 'No tiene permisos para ver este producto.')
        return redirect('dashboard')

    producto = get_object_or_404(Producto, pk=producto_id)
    movimientos = producto.movimientos.all()[:50]

    return render(request, 'bodega/detalle_producto.html', {
        'producto': producto,
        'movimientos': movimientos,
        'titulo': f'Producto: {producto.nombre}',
    })


@login_required
def crear_solicitud(request):
    """
    Vista para crear una solicitud de materiales a bodega.
    Accesible por: funcionario, bodeguero, jefatura, admin.
    """
    if not (
        request.user.es_funcionario
        or request.user.es_bodeguero
        or request.user.es_jefatura
        or request.user.es_admin
    ):
        messages.error(request, 'No tiene permisos para crear solicitudes.')
        return redirect('dashboard')

    if request.method == 'POST':
        form = FormularioSolicitudBodega(request.POST)
        if form.is_valid():
            with transaction.atomic():
                solicitud = form.save(commit=False)
                solicitud.solicitante = request.user
                if request.user.departamento:
                    solicitud.departamento_solicitante = request.user.departamento
                solicitud.estado = 'ingresada'
                solicitud.save()

                messages.success(
                    request,
                    f'¡Solicitud {solicitud.codigo} creada! Ahora agregue los productos que necesita.',
                )
                return redirect('bodega:agregar_productos', solicitud_id=solicitud.pk)
    else:
        form = FormularioSolicitudBodega(initial={
            'departamento_solicitante': request.user.departamento,
        })

    return render(request, 'bodega/crear_solicitud.html', {
        'form': form,
        'titulo': 'Nueva Solicitud de Materiales',
    })


@login_required
def agregar_productos(request, solicitud_id):
    """
    Agregar productos a una solicitud existente.
    """
    solicitud = get_object_or_404(SolicitudBodega, pk=solicitud_id)

    # Verificar permisos: solo el creador puede agregar productos
    if solicitud.solicitante != request.user and not request.user.es_admin:
        messages.error(request, 'Solo el creador puede modificar esta solicitud.')
        return redirect('bodega:detalle_solicitud', solicitud_id=solicitud.pk)

    if solicitud.estado not in ['ingresada', 'pendiente']:
        messages.error(request, 'Esta solicitud ya no se puede modificar.')
        return redirect('bodega:detalle_solicitud', solicitud_id=solicitud.pk)

    detalles = solicitud.detalles.all()

    if request.method == 'POST':
        form = FormularioDetalleSolicitud(request.POST)
        if form.is_valid():
            detalle = form.save(commit=False)
            detalle.solicitud = solicitud

            # Verificar que no exceda el stock
            if detalle.cantidad_solicitada > detalle.producto.stock_actual:
                messages.warning(
                    request,
                    f'Solo hay {detalle.producto.stock_actual} unidades de '
                    f'"{detalle.producto.nombre}". Se ajustó a la cantidad disponible.',
                )
                detalle.cantidad_solicitada = detalle.producto.stock_actual

            detalle.save()
            messages.success(
                request,
                f'{detalle.producto.nombre} agregado a la solicitud.',
            )
            return redirect('bodega:agregar_productos', solicitud_id=solicitud.pk)
    else:
        form = FormularioDetalleSolicitud()

    return render(request, 'bodega/agregar_productos.html', {
        'solicitud': solicitud,
        'detalles': detalles,
        'form': form,
        'titulo': f'Agregar productos - {solicitud.codigo}',
    })


@login_required
def mis_solicitudes(request):
    """
    Lista de solicitudes creadas por el usuario.
    """
    if not (
        request.user.es_funcionario
        or request.user.es_bodeguero
        or request.user.es_jefatura
        or request.user.es_admin
    ):
        messages.error(request, 'No tiene permisos para ver solicitudes.')
        return redirect('dashboard')

    solicitudes = SolicitudBodega.objects.filter(
        solicitante=request.user
    ).order_by('-creado_en')

    return render(request, 'bodega/mis_solicitudes.html', {
        'solicitudes': solicitudes,
        'titulo': 'Mis Solicitudes de Bodega',
    })


@login_required
def detalle_solicitud(request, solicitud_id):
    """
    Vista de detalle de una solicitud de bodega.
    """
    solicitud = get_object_or_404(SolicitudBodega, pk=solicitud_id)

    # Permisos: creador, bodeguero, jefatura, admin
    if not (
        solicitud.solicitante == request.user
        or request.user.es_bodeguero
        or request.user.es_jefatura
        or request.user.es_admin
    ):
        messages.error(request, 'No tiene permisos para ver esta solicitud.')
        return redirect('dashboard')

    # Formulario de aprobación (solo jefatura/admin)
    form_aprobar = None
    if (
        request.user.es_jefatura or request.user.es_admin
    ) and solicitud.estado in ['pendiente', 'ingresada']:
        if request.method == 'POST' and 'aprobar' in request.POST:
            form_aprobar = FormularioAprobarSolicitud(request.POST, instance=solicitud)
            if form_aprobar.is_valid():
                solicitud_actualizada = form_aprobar.save(commit=False)
                solicitud_actualizada.aprobado_por = request.user
                solicitud_actualizada.save()

                estado = solicitud_actualizada.get_estado_display()
                messages.success(request, f'Solicitud {estado.lower()} correctamente.')
                return redirect(
                    'bodega:detalle_solicitud',
                    solicitud_id=solicitud.pk,
                )
        else:
            form_aprobar = FormularioAprobarSolicitud(instance=solicitud)

    # Formulario de entrega (solo bodeguero)
    form_entregar = None
    if (
        request.user.es_bodeguero
    ) and solicitud.estado == 'aprobada':
        if request.method == 'POST' and 'entregar' in request.POST:
            with transaction.atomic():
                solicitud.estado = 'entregada'
                solicitud.save()

                # Actualizar stock de productos entregados
                for detalle in solicitud.detalles.all():
                    producto = detalle.producto
                    cantidad_entregar = min(
                        detalle.cantidad_solicitada,
                        producto.stock_actual,
                    )
                    if cantidad_entregar > 0:
                        stock_anterior = producto.stock_actual
                        producto.stock_actual -= cantidad_entregar
                        producto.save()

                        MovimientoStock.objects.create(
                            producto=producto,
                            tipo='salida',
                            cantidad=cantidad_entregar,
                            stock_anterior=stock_anterior,
                            stock_resultante=producto.stock_actual,
                            usuario=request.user,
                            observacion=f'Entrega por solicitud {solicitud.codigo}',
                        )

                        detalle.cantidad_entregada = cantidad_entregar
                        detalle.save()

                messages.success(
                    request,
                    f'Solicitud {solicitud.codigo} marcada como entregada. Stock actualizado.',
                )
                return redirect('bodega:detalle_solicitud', solicitud_id=solicitud.pk)

    return render(request, 'bodega/detalle_solicitud.html', {
        'solicitud': solicitud,
        'form_aprobar': form_aprobar,
        'form_entregar': form_entregar,
        'titulo': f'Solicitud {solicitud.codigo}',
    })


@login_required
def solicitudes_pendientes(request):
    """
    Panel para bodeguero: todas las solicitudes pendientes y aprobadas.
    """
    if not (request.user.es_bodeguero or request.user.es_admin):
        messages.error(request, 'No tiene permisos para esta sección.')
        return redirect('dashboard')

    solicitudes = SolicitudBodega.objects.exclude(
        estado__in=['ingresada']
    ).order_by('-creado_en')

    # Estadísticas
    totales = {
        'pendientes': SolicitudBodega.objects.filter(estado='pendiente').count(),
        'aprobadas': SolicitudBodega.objects.filter(estado='aprobada').count(),
        'entregadas': SolicitudBodega.objects.filter(estado='entregada').count(),
        'rechazadas': SolicitudBodega.objects.filter(estado='rechazada').count(),
    }

    return render(request, 'bodega/solicitudes_pendientes.html', {
        'solicitudes': solicitudes,
        'totales': totales,
        'titulo': 'Solicitudes de Bodega',
    })
