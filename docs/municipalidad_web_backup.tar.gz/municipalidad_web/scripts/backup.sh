#!/bin/bash
# scripts/backup.sh
# Backup de la base de datos PostgreSQL - Portal Municipal La Estrella

FECHA=$(date +%Y%m%d_%H%M%S)
DIRECTORIO_BACKUP="/root/backups"
ARCHIVO="$DIRECTORIO_BACKUP/municipalidad_db_$FECHA.sql.gz"

DB_NAME="municipalidad_db"
DB_USER="municipalidad_user"

echo "=== Backup Portal Municipal La Estrella ==="
echo "Fecha: $(date)"
echo "Archivo: $ARCHIVO"

pg_dump -h localhost -U $DB_USER $DB_NAME | gzip > $ARCHIVO

if [ $? -eq 0 ]; then
    TAMANIO=$(du -sh $ARCHIVO | cut -f1)
    echo "✓ Backup exitoso — Tamaño: $TAMANIO"
    echo "✓ Guardado en: $ARCHIVO"
else
    echo "✗ Error al generar el backup"
    exit 1
fi

# Eliminar backups con más de 7 días
find $DIRECTORIO_BACKUP -name "*.sql.gz" -mtime +7 -delete
echo "✓ Backups antiguos eliminados (>7 días)"
