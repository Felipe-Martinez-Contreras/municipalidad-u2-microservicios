#!/bin/bash
# scripts/restore.sh
# Restauración de backup - Portal Municipal La Estrella
# Uso: ./restore.sh /ruta/al/archivo.sql.gz

if [ -z "$1" ]; then
    echo "Uso: $0 <archivo_backup.sql.gz>"
    echo "Backups disponibles:"
    ls -lh /root/backups/*.sql.gz 2>/dev/null || echo "  Sin backups disponibles"
    exit 1
fi

ARCHIVO=$1
DB_NAME="municipalidad_db"
DB_USER="municipalidad_user"

if [ ! -f "$ARCHIVO" ]; then
    echo "✗ Archivo no encontrado: $ARCHIVO"
    exit 1
fi

echo "=== Restauración Portal Municipal La Estrella ==="
echo "Archivo: $ARCHIVO"
read -p "¿Confirma la restauración? Esto sobreescribirá la base de datos actual. (s/N): " CONFIRMAR

if [ "$CONFIRMAR" != "s" ]; then
    echo "Restauración cancelada."
    exit 0
fi

echo "Restaurando..."
gunzip -c $ARCHIVO | psql -h localhost -U $DB_USER $DB_NAME

if [ $? -eq 0 ]; then
    echo "✓ Restauración exitosa"
else
    echo "✗ Error durante la restauración"
    exit 1
fi
