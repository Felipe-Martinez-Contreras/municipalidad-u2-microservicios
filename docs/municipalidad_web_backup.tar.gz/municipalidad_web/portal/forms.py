# portal/forms.py
# Formularios para autenticación y registro de usuarios
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.core.exceptions import ValidationError

Usuario = get_user_model()


class FormularioLogin(AuthenticationForm):
    """
    Formulario de inicio de sesión con email en lugar de username.
    """

    username = forms.EmailField(
        label='Correo electrónico',
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'ejemplo@correo.com',
            'autofocus': True,
        }),
    )

    password = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Ingrese su contraseña',
        }),
    )

    error_messages = {
        'invalid_login': 'Correo o contraseña incorrectos. Intente nuevamente.',
        'inactive': 'Esta cuenta está desactivada. Contacte al administrador.',
    }

    class Meta:
        fields = ['username', 'password']


class FormularioRegistroCiudadano(forms.ModelForm):
    """
    Formulario de registro para ciudadanos.
    Rol fijo: 'ciudadano'.
    """

    password1 = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Mínimo 8 caracteres',
        }),
    )

    password2 = forms.CharField(
        label='Confirmar contraseña',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Repita la contraseña',
        }),
    )

    class Meta:
        model = Usuario
        fields = ['first_name', 'last_name', 'email', 'rut', 'telefono']
        labels = {
            'first_name': 'Nombres',
            'last_name': 'Apellidos',
            'email': 'Correo electrónico',
            'rut': 'RUT',
            'telefono': 'Teléfono (opcional)',
        }
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: María José',
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: González Muñoz',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'ejemplo@correo.com',
            }),
            'rut': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '12345678-9',
            }),
            'telefono': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '+56912345678',
            }),
        }

    def clean_password2(self):
        """Valida que ambas contraseñas coincidan."""
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            raise ValidationError('Las contraseñas no coinciden.')
        return password2

    def save(self, commit=True):
        """Guarda el usuario con rol fijo de ciudadano."""
        usuario = super().save(commit=False)
        usuario.set_password(self.cleaned_data['password1'])
        usuario.rol = 'ciudadano'
        # Generar username a partir del email
        if not usuario.username:
            base_username = usuario.email.split('@')[0]
            username = base_username
            contador = 1
            while Usuario.objects.filter(username=username).exists():
                username = f'{base_username}{contador}'
                contador += 1
            usuario.username = username
        if commit:
            usuario.save()
        return usuario


class FormularioCrearFuncionario(forms.ModelForm):
    """
    Formulario para que ADMIN cree funcionarios municipales.
    Incluye selección de rol y departamento.
    """

    password1 = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Mínimo 8 caracteres',
        }),
    )

    password2 = forms.CharField(
        label='Confirmar contraseña',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Repita la contraseña',
        }),
    )

    class Meta:
        model = Usuario
        fields = [
            'first_name', 'last_name', 'email', 'rut', 'telefono',
            'rol', 'departamento',
        ]
        labels = {
            'first_name': 'Nombres',
            'last_name': 'Apellidos',
            'email': 'Correo electrónico',
            'rut': 'RUT',
            'telefono': 'Teléfono (opcional)',
            'rol': 'Rol',
            'departamento': 'Departamento',
        }
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: Juan Carlos',
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: Pérez Silva',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'funcionario@municipalidad.cl',
            }),
            'rut': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '12345678-9',
            }),
            'telefono': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '+56912345678',
            }),
            'rol': forms.Select(attrs={'class': 'form-select'}),
            'departamento': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Excluir 'ciudadano' de las opciones de rol para funcionarios
        choices = [
            c for c in Usuario.RolChoices.choices if c[0] != 'ciudadano'
        ]
        self.fields['rol'].choices = choices

    def clean_departamento(self):
        """Departamento obligatorio, excepto para admin."""
        rol = self.cleaned_data.get('rol')
        depto = self.cleaned_data.get('departamento')
        if rol != 'admin' and not depto:
            raise ValidationError(
                'Debe seleccionar un departamento para este rol.'
            )
        return depto

    def clean_password2(self):
        """Valida que ambas contraseñas coincidan."""
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            raise ValidationError('Las contraseñas no coinciden.')
        return password2

    def save(self, commit=True):
        """Guarda el funcionario con el rol y departamento asignados."""
        usuario = super().save(commit=False)
        usuario.set_password(self.cleaned_data['password1'])
        if not usuario.username:
            base_username = usuario.email.split('@')[0]
            username = base_username
            contador = 1
            while Usuario.objects.filter(username=username).exists():
                username = f'{base_username}{contador}'
                contador += 1
            usuario.username = username
        if commit:
            usuario.save()
        return usuario
