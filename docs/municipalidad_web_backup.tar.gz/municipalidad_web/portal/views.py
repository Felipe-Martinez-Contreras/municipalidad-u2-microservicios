# portal/views.py
# Vistas para autenticación, registro y panel de usuario
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import (
    FormularioLogin,
    FormularioRegistroCiudadano,
    FormularioCrearFuncionario,
)

#def test_error_view(request):
    # Esto genera un error 500 porque no se puede dividir por cero
 #   resultado = 1 / 0
  #  return HttpResponse("Este mensaje no se verá por el error")


def inicio(request):
    """
    Página de inicio pública.
    Si el usuario ya está autenticado, lo redirige al dashboard.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'portal/inicio.html')


def login_view(request):
    """
    Vista de inicio de sesión.
    Redirige según el rol del usuario después de autenticarse.
    """
    # Si ya está autenticado, redirigir al dashboard
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = FormularioLogin(data=request.POST, request=request)
        if form.is_valid():
            usuario = form.get_user()
            login(request, usuario)
            messages.success(
                request,
                f'¡Bienvenido/a, {usuario.first_name}! Has iniciado sesión correctamente.',
            )
            # Redirección según rol
            redirecciones = {
                'ciudadano': 'dashboard',    # /dashboard/
                'funcionario': 'dashboard',   # /dashboard/
                'bodeguero': 'dashboard',      # /dashboard/
                'jefatura': 'dashboard',       # /dashboard/
                'admin': '/admin/',            # Django admin
            }
            destino = redirecciones.get(usuario.rol, 'dashboard')
            if destino.startswith('/'):
                return redirect(destino)
            return redirect(destino)
        else:
            messages.error(
                request,
                'Credenciales inválidas. Por favor verifique su correo y contraseña.',
            )
    else:
        form = FormularioLogin(request=request)

    return render(request, 'portal/login.html', {'form': form})


def logout_view(request):
    """
    Cierra la sesión del usuario y lo redirige a la página de inicio.
    """
    logout(request)
    messages.info(request, 'Has cerrado sesión correctamente.')
    return redirect('inicio')


def registro_view(request):
    """
    Vista de registro para ciudadanos.
    El rol se asigna automáticamente como 'ciudadano'.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = FormularioRegistroCiudadano(request.POST)
        if form.is_valid():
            usuario = form.save()
            login(request, usuario)
            messages.success(
                request,
                f'¡Registro exitoso! Bienvenido/a al Portal Municipal, {usuario.first_name}.',
            )
            return redirect('dashboard')
        else:
            messages.error(
                request,
                'Por favor corrija los errores en el formulario.',
            )
    else:
        form = FormularioRegistroCiudadano()

    return render(request, 'portal/registro.html', {'form': form})


@login_required
def dashboard_view(request):
    """
    Panel principal después de iniciar sesión.
    Muestra información según el rol del usuario.
    """
    usuario = request.user
    contexto = {
        'usuario': usuario,
        'rol_display': usuario.get_rol_display(),
        'depto_display': usuario.get_departamento_display() or 'No asignado',
    }
    return render(request, 'portal/dashboard.html', contexto)
