# administracion/urls.py
from django.urls import path
from . import views

app_name = 'administracion'

urlpatterns = [
    path('', views.dashboard_admin, name='dashboard'),
    path('funcionarios/', views.lista_funcionarios, name='lista_funcionarios'),
    path('funcionarios/crear/', views.crear_funcionario, name='crear_funcionario'),
    path('funcionarios/<int:pk>/toggle/', views.toggle_funcionario, name='toggle_funcionario'),
    path('reportes/tramites/', views.reporte_tramites, name='reporte_tramites'),
    path('reportes/bodega/', views.reporte_bodega, name='reporte_bodega'),
]
