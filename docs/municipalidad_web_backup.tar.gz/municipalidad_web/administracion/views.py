# administracion/views.py
# Vistas del panel administrativo - Portal Municipal La Estrella
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Q

from usuarios.models import Usuario
from tramites.models import Tramite
from bodega.models import Producto, SolicitudBodega


def solo_admin(view_func):
    """Decorador: solo permite acceso a usuarios con rol admin."""
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('portal:login')
        if not request.user.es_admin:
            messages.error(request, 'No tiene permisos para acceder a esta sección.')
            return redirect('dashboard')
        return view_func(request, *args, **kwargs)
    return wrapper


def admin_o_jefatura(view_func):
    """Decorador: permite acceso a admin y jefatura."""
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('portal:login')
        if not (request.user.es_admin or request.user.es_jefatura):
            messages.error(request, 'No tiene permisos para acceder a esta sección.')
            return redirect('dashboard')
        return view_func(request, *args, **kwargs)
    return wrapper


@solo_admin
def dashboard_admin(request):
    """Dashboard principal del administrador con estadísticas generales."""
    contexto = {
        'titulo': 'Panel Administrativo',
        # Usuarios
        'total_usuarios': Usuario.objects.count(),
        'total_funcionarios': Usuario.objects.filter(
            rol__in=['funcionario', 'bodeguero', 'jefatura', 'admin']
        ).count(),
        'usuarios_activos': Usuario.objects.filter(is_active=True).count(),
        # Trámites
        'tramites_activos': Tramite.objects.exclude(
            estado__in=['cerrado', 'rechazado']
        ).count(),
        'tramites_pendientes': Tramite.objects.filter(estado='pendiente').count(),
        'tramites_por_estado': Tramite.objects.values('estado').annotate(
            total=Count('id')
        ).order_by('-total'),
        # Bodega
        'solicitudes_pendientes': SolicitudBodega.objects.filter(
            estado='pendiente'
        ).count(),
        'productos_stock_bajo': Producto.objects.filter(activo=True).filter(
            stock_actual__lte=10
        ).count(),
        'total_productos': Producto.objects.filter(activo=True).count(),
    }
    return render(request, 'administracion/dashboard.html', contexto)


@solo_admin
def lista_funcionarios(request):
    """Lista todos los funcionarios con filtros por departamento y rol."""
    funcionarios = Usuario.objects.exclude(rol='ciudadano').order_by('departamento', 'last_name')

    # Filtros opcionales
    departamento = request.GET.get('departamento', '')
    rol = request.GET.get('rol', '')
    activo = request.GET.get('activo', '')

    if departamento:
        funcionarios = funcionarios.filter(departamento=departamento)
    if rol:
        funcionarios = funcionarios.filter(rol=rol)
    if activo != '':
        funcionarios = funcionarios.filter(is_active=activo == '1')

    contexto = {
        'titulo': 'Gestión de Funcionarios',
        'funcionarios': funcionarios,
        'departamentos': Usuario.DeptoChoices.choices,
        'roles': [c for c in Usuario.RolChoices.choices if c[0] != 'ciudadano'],
        'filtro_departamento': departamento,
        'filtro_rol': rol,
        'filtro_activo': activo,
    }
    return render(request, 'administracion/lista_funcionarios.html', contexto)


@solo_admin
def crear_funcionario(request):
    """Crear un nuevo funcionario desde el panel admin."""
    from portal.forms import FormularioCrearFuncionario
    if request.method == 'POST':
        form = FormularioCrearFuncionario(request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.set_password(form.cleaned_data['password1'])
            usuario.save()
            messages.success(request, f'Funcionario {usuario.get_full_name()} creado correctamente.')
            return redirect('administracion:lista_funcionarios')
    else:
        form = FormularioCrearFuncionario()
    return render(request, 'administracion/crear_funcionario.html', {
        'titulo': 'Crear Funcionario',
        'form': form,
    })


@solo_admin
def toggle_funcionario(request, pk):
    """Activar o desactivar un funcionario."""
    funcionario = get_object_or_404(Usuario, pk=pk)
    if funcionario.es_admin:
        messages.error(request, 'No puede desactivar a otro administrador.')
        return redirect('administracion:lista_funcionarios')
    funcionario.is_active = not funcionario.is_active
    funcionario.save()
    estado = 'activado' if funcionario.is_active else 'desactivado'
    messages.success(request, f'Funcionario {funcionario.get_full_name()} {estado}.')
    return redirect('administracion:lista_funcionarios')


@admin_o_jefatura
def reporte_tramites(request):
    """Reporte de trámites filtrable por departamento y estado."""
    tramites = Tramite.objects.select_related("tipo", "ciudadano", "funcionario_asignado").order_by('-creado_en')

    departamento = request.GET.get('departamento', '')
    estado = request.GET.get('estado', '')

    if departamento:
        tramites = tramites.filter(ciudadano__departamento=departamento)
    if estado:
        tramites = tramites.filter(estado=estado)

    # Estadísticas por estado
    stats = Tramite.objects.values('estado').annotate(total=Count('id')).order_by('estado')

    contexto = {
        'titulo': 'Reporte de Trámites',
        'tramites': tramites[:100],  # limitar para la demo
        'stats': stats,
        'departamentos': Usuario.DeptoChoices.choices,
        'estados': Tramite.EstadoChoices.choices,
        'filtro_departamento': departamento,
        'filtro_estado': estado,
    }
    return render(request, 'administracion/reporte_tramites.html', contexto)


@admin_o_jefatura
def reporte_bodega(request):
    """Reporte de bodega: stock bajo y solicitudes recientes."""
    from django.utils import timezone
    from datetime import timedelta

    hace_30_dias = timezone.now() - timedelta(days=30)

    productos_stock_bajo = Producto.objects.filter(
        activo=True,
        stock_actual__lte=10
    ).order_by('stock_actual')

    solicitudes_mes = SolicitudBodega.objects.filter(
        creado_en__gte=hace_30_dias
    ).select_related('solicitante').order_by('-creado_en')

    contexto = {
        'titulo': 'Reporte de Bodega',
        'productos_stock_bajo': productos_stock_bajo,
        'solicitudes_mes': solicitudes_mes,
        'total_stock_bajo': productos_stock_bajo.count(),
        'total_solicitudes_mes': solicitudes_mes.count(),
    }
    return render(request, 'administracion/reporte_bodega.html', contexto)
